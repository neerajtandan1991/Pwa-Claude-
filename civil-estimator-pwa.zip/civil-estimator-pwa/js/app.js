/**
 * Main app controller. Plain JS SPA, no framework/build step —
 * everything runs directly in the browser, fully offline after first load.
 */

const App = {
  state: {
    view: "home", // home | project | letterhead
    currentProjectId: null,
    activeTab: "boq", // boq | estimate | wpr | photos
    expandedBoqItemId: null,
    wprBillNo: 1
  },

  async init() {
    document.getElementById("app").addEventListener("click", App.handleClick);
    document.getElementById("app").addEventListener("submit", App.handleSubmit);
    document.getElementById("app").addEventListener("change", App.handleChange);
    await App.renderHome();
    App.updateOnlineBadge();
    window.addEventListener("online", App.updateOnlineBadge);
    window.addEventListener("offline", App.updateOnlineBadge);
  },

  updateOnlineBadge() {
    const el = document.getElementById("connStatus");
    if (!el) return;
    if (navigator.onLine) {
      el.textContent = "Online";
      el.className = "badge online";
    } else {
      el.textContent = "Offline (working from device storage)";
      el.className = "badge offline";
    }
  },

  escapeHtml(str) {
    return String(str == null ? "" : str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  },

  // ============================================================
  // HOME — Project list
  // ============================================================
  async renderHome() {
    App.state.view = "home";
    const projects = (await DB.getAll("projects")).sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
    const html = `
      <div class="topbar">
        <h1>🏗️ Civil Estimator</h1>
        <div id="connStatus" class="badge"></div>
      </div>
      <div class="content">
        <div class="row-actions">
          <button class="btn primary" data-action="new-project">+ New Project</button>
          <button class="btn" data-action="open-letterhead">Letterhead Settings</button>
        </div>
        <h2>Projects</h2>
        ${projects.length === 0 ? '<p class="muted">No projects yet. Create one to get started — all data stays on this device.</p>' : ""}
        <div class="card-list">
          ${projects
            .map(
              (p) => `
            <div class="card" data-action="open-project" data-id="${p.id}">
              <div class="card-title">${App.escapeHtml(p.name)}</div>
              <div class="card-sub">${App.escapeHtml(p.location || "")}</div>
              <div class="card-meta">Bill No ${App.escapeHtml(p.billNo)} · Contractor: ${App.escapeHtml(p.contractorName || "-")}</div>
              <button class="btn danger small" data-action="delete-project" data-id="${p.id}">Delete</button>
            </div>`
            )
            .join("")}
        </div>
      </div>
    `;
    document.getElementById("app").innerHTML = html;
    App.updateOnlineBadge();
  },

  renderNewProjectForm() {
    document.getElementById("app").innerHTML = `
      <div class="topbar"><button class="btn" data-action="go-home">← Back</button><h1>New Project</h1></div>
      <div class="content">
        <form data-form="new-project">
          <label>Project Name<input name="name" required placeholder="e.g. Construction of Ward Office Building"></label>
          <label>Location<input name="location" placeholder="e.g. Gaindakot-02"></label>
          <label>Contract ID<input name="contractId"></label>
          <label>Contractor Name<input name="contractorName"></label>
          <label>Agreement Date<input name="agreementDate" placeholder="YYYY/MM/DD"></label>
          <label>Work Order Date<input name="workOrderDate" placeholder="YYYY/MM/DD"></label>
          <label>Work Completion Date<input name="completionDate" placeholder="YYYY/MM/DD"></label>
          <label>Current Bill No<input name="billNo" type="number" min="1" value="1"></label>
          <label>VAT %<input name="vatPercent" type="number" value="13"></label>
          <label class="checkbox-row"><input type="checkbox" name="useTemplate" checked> Start from the sample Ward Office BOQ template (fully editable)</label>
          <button class="btn primary" type="submit">Create Project</button>
        </form>
      </div>
    `;
  },

  async createProjectFromForm(form) {
    const fd = new FormData(form);
    const project = await DB.createProject({
      name: fd.get("name"),
      location: fd.get("location"),
      contractId: fd.get("contractId"),
      contractorName: fd.get("contractorName"),
      agreementDate: fd.get("agreementDate"),
      workOrderDate: fd.get("workOrderDate"),
      completionDate: fd.get("completionDate"),
      billNo: fd.get("billNo") || "1",
      vatPercent: parseFloat(fd.get("vatPercent")) || 13
    });
    if (fd.get("useTemplate")) {
      await DB.seedBoqFromTemplate(project.id, DEFAULT_BOQ_TEMPLATE);
    }
    App.state.currentProjectId = project.id;
    App.state.activeTab = "boq";
    await App.renderProject();
  },

  // ============================================================
  // PROJECT WORKSPACE
  // ============================================================
  async renderProject() {
    App.state.view = "project";
    const project = await DB.get("projects", App.state.currentProjectId);
    if (!project) return App.renderHome();

    const tabs = [
      ["boq", "BOQ & Measurements"],
      ["estimate", "Estimate"],
      ["wpr", "Progress Report"],
      ["photos", "Photos"],
      ["info", "Project Info"]
    ];

    let bodyHtml = "";
    if (App.state.activeTab === "boq") bodyHtml = await App.renderBoqTab(project);
    else if (App.state.activeTab === "estimate") bodyHtml = await App.renderEstimateTab(project);
    else if (App.state.activeTab === "wpr") bodyHtml = await App.renderWprTab(project);
    else if (App.state.activeTab === "photos") bodyHtml = await App.renderPhotosTab(project);
    else if (App.state.activeTab === "info") bodyHtml = App.renderInfoTab(project);

    document.getElementById("app").innerHTML = `
      <div class="topbar">
        <button class="btn" data-action="go-home">← Projects</button>
        <h1 title="${App.escapeHtml(project.name)}">${App.escapeHtml(project.name)}</h1>
        <div id="connStatus" class="badge"></div>
      </div>
      <div class="tabs">
        ${tabs.map(([k, label]) => `<button class="tab ${App.state.activeTab === k ? "active" : ""}" data-action="set-tab" data-tab="${k}">${label}</button>`).join("")}
      </div>
      <div class="content">${bodyHtml}</div>
    `;
    App.updateOnlineBadge();
  },

  renderInfoTab(project) {
    return `
      <form data-form="edit-project">
        <label>Project Name<input name="name" required value="${App.escapeHtml(project.name)}"></label>
        <label>Location<input name="location" value="${App.escapeHtml(project.location || "")}"></label>
        <label>Contract ID<input name="contractId" value="${App.escapeHtml(project.contractId || "")}"></label>
        <label>Contractor Name<input name="contractorName" value="${App.escapeHtml(project.contractorName || "")}"></label>
        <label>Agreement Date<input name="agreementDate" value="${App.escapeHtml(project.agreementDate || "")}"></label>
        <label>Work Order Date<input name="workOrderDate" value="${App.escapeHtml(project.workOrderDate || "")}"></label>
        <label>Work Completion Date<input name="completionDate" value="${App.escapeHtml(project.completionDate || "")}"></label>
        <label>Current Bill No<input name="billNo" type="number" min="1" value="${App.escapeHtml(project.billNo)}"></label>
        <label>VAT %<input name="vatPercent" type="number" value="${App.escapeHtml(project.vatPercent)}"></label>
        <button class="btn primary" type="submit">Save Project Info</button>
      </form>
    `;
  },

  // ---------------- BOQ & Measurements ----------------
  async renderBoqTab(project) {
    const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
    const measurements = await DB.getAllByIndex("measurements", "projectId", project.id);
    const photos = await DB.getAllByIndex("photos", "projectId", project.id);

    const byCategory = {};
    for (const it of boqItems) {
      byCategory[it.categoryCode] = byCategory[it.categoryCode] || { name: it.categoryName, items: [] };
      byCategory[it.categoryCode].items.push(it);
    }

    let html = `
      <div class="row-actions">
        <button class="btn primary" data-action="add-boq-item">+ Add BOQ Item</button>
      </div>
    `;

    for (const code of Object.keys(byCategory).sort()) {
      const cat = byCategory[code];
      html += `<h3 class="cat-header">${code} — ${App.escapeHtml(cat.name)}</h3>`;
      for (const item of cat.items) {
        const itemMeasurements = measurements.filter((m) => m.boqItemId === item.id);
        const qty = Calc.upToDateQuantity(measurements, item.id, project.billNo, item.isLumpSum);
        const amount = Calc.amount(qty, item.rate);
        const itemPhotos = photos.filter((p) => p.boqItemId === item.id);
        const expanded = App.state.expandedBoqItemId === item.id;

        html += `
          <div class="boq-item">
            <div class="boq-item-head" data-action="toggle-boq-item" data-id="${item.id}">
              <div>
                <strong>${App.escapeHtml(item.sNo)}</strong> ${App.escapeHtml(item.description)}
                <div class="muted small">${App.escapeHtml(item.unit)} · Rate ${Calc.fmt(item.rate)} · Qty ${Calc.fmt(qty)} · Amount ${Calc.fmt(amount)}</div>
              </div>
              <span class="chevron">${expanded ? "▲" : "▼"}</span>
            </div>
            ${expanded ? App.renderBoqItemDetail(project, item, itemMeasurements, itemPhotos) : ""}
          </div>
        `;
      }
    }
    return html;
  },

  renderBoqItemDetail(project, item, measurements, photos) {
    const stageLabels = { before: "Before", during: "During", after: "After" };
    return `
      <div class="boq-item-body">
        <div class="row-actions">
          <button class="btn small" data-action="edit-boq-item" data-id="${item.id}">Edit Item</button>
          <button class="btn small danger" data-action="delete-boq-item" data-id="${item.id}">Delete Item</button>
          <button class="btn small primary" data-action="add-measurement" data-id="${item.id}">+ Add Measurement (this bill)</button>
        </div>

        <div class="photo-row">
          ${["before", "during", "after"]
            .map((stage) => {
              const p = photos.filter((ph) => ph.stage === stage);
              return `
              <div class="photo-slot">
                <div class="photo-slot-label">${stageLabels[stage]}</div>
                <div class="photo-thumbs">
                  ${p
                    .map(
                      (ph) => `<div class="thumb-wrap"><img class="thumb" src="${Camera.blobToObjectUrl(ph.blob)}"><button class="thumb-del" data-action="delete-photo" data-id="${ph.id}">×</button></div>`
                    )
                    .join("")}
                </div>
                <button class="btn small" data-action="take-photo" data-id="${item.id}" data-stage="${stage}">📷 Add ${stageLabels[stage]} Photo</button>
              </div>
            `;
            })
            .join("")}
        </div>

        <table class="mini-table">
          <thead><tr><th>Bill</th><th>Label</th><th>Qty</th><th>Remarks</th><th></th></tr></thead>
          <tbody>
            ${measurements
              .map(
                (m) => `
              <tr>
                <td>${App.escapeHtml(m.billNo)}</td>
                <td>${App.escapeHtml(m.label || "-")}</td>
                <td>${Calc.fmt(m.quantity)}</td>
                <td>${App.escapeHtml(m.remarks || "")}</td>
                <td>
                  <button class="btn tiny" data-action="edit-measurement" data-id="${m.id}">Edit</button>
                  <button class="btn tiny danger" data-action="delete-measurement" data-id="${m.id}">Del</button>
                </td>
              </tr>`
              )
              .join("")}
            ${measurements.length === 0 ? '<tr><td colspan="5" class="muted">No measurements recorded yet.</td></tr>' : ""}
          </tbody>
        </table>
      </div>
    `;
  },

  async renderMeasurementForm(boqItemId, measurementId) {
    const item = await DB.get("boqItems", boqItemId);
    const project = await DB.get("projects", item.projectId);
    let record = measurementId ? await DB.get("measurements", measurementId) : null;
    const rows = record ? record.rows : [{ id: DB.uid("row"), particular: "", length: "", breadth: "", height: "", no: "" }];

    document.getElementById("app").innerHTML = `
      <div class="topbar"><button class="btn" data-action="back-to-boq">← Back</button><h1>Measurement</h1></div>
      <div class="content">
        <p><strong>${App.escapeHtml(item.sNo)}</strong> ${App.escapeHtml(item.description)}</p>
        <form data-form="measurement" data-boq-id="${item.id}" data-meas-id="${measurementId || ""}">
          <label>Bill No<input name="billNo" type="number" min="1" value="${record ? record.billNo : project.billNo}"></label>
          <label>Label / Location (e.g. "Footing F1", "Grid A-A")<input name="label" value="${record ? App.escapeHtml(record.label) : ""}"></label>
          ${item.isLumpSum ? '<p class="muted">This is a Provisional Sum (lump sum) item — quantity is fixed at 1 when claimed. No L×B×H rows needed.</p>' : `
          <table class="row-table" id="rowsTable">
            <thead><tr><th>Particular</th><th>Length</th><th>Breadth</th><th>Height</th><th>No.</th><th>Qty</th><th></th></tr></thead>
            <tbody>
              ${rows.map((r) => App.rowHtml(r)).join("")}
            </tbody>
          </table>
          <button type="button" class="btn small" data-action="add-row">+ Add Row</button>
          <div class="total-line">Total Quantity: <span id="rowsTotal">${Calc.fmt(Calc.computeRows(rows).total)}</span> ${App.escapeHtml(item.unit)}</div>
          `}
          <label>Remarks<textarea name="remarks">${record ? App.escapeHtml(record.remarks) : ""}</textarea></label>
          <button class="btn primary" type="submit">Save Measurement</button>
        </form>
      </div>
    `;
    App._isLumpSum = item.isLumpSum;
    App.recalcRowsTotal();
  },

  rowHtml(r) {
    return `
      <tr data-row-id="${r.id}">
        <td><input class="cell" data-f="particular" value="${App.escapeHtml(r.particular || "")}" placeholder="e.g. Footing F1"></td>
        <td><input class="cell num" data-f="length" type="number" step="any" value="${r.length != null ? r.length : ""}"></td>
        <td><input class="cell num" data-f="breadth" type="number" step="any" value="${r.breadth != null ? r.breadth : ""}"></td>
        <td><input class="cell num" data-f="height" type="number" step="any" value="${r.height != null ? r.height : ""}"></td>
        <td><input class="cell num" data-f="no" type="number" step="any" value="${r.no != null ? r.no : ""}" placeholder="1"></td>
        <td class="row-qty">0.00</td>
        <td><button type="button" class="btn tiny danger" data-action="remove-row">×</button></td>
      </tr>
    `;
  },

  recalcRowsTotal() {
    const table = document.getElementById("rowsTable");
    if (!table) return;
    let total = 0;
    table.querySelectorAll("tbody tr").forEach((tr) => {
      const row = {
        length: tr.querySelector('[data-f="length"]').value,
        breadth: tr.querySelector('[data-f="breadth"]').value,
        height: tr.querySelector('[data-f="height"]').value,
        no: tr.querySelector('[data-f="no"]').value
      };
      const qty = Calc.rowQty(row);
      tr.querySelector(".row-qty").textContent = Calc.fmt(qty);
      total += qty;
    });
    const totalEl = document.getElementById("rowsTotal");
    if (totalEl) totalEl.textContent = Calc.fmt(total);
  },

  // ---------------- Estimate tab ----------------
  async renderEstimateTab(project) {
    const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
    const measurements = await DB.getAllByIndex("measurements", "projectId", project.id);
    const estimate = Calc.buildEstimate(project, boqItems, measurements, project.billNo);

    let html = `
      <div class="row-actions">
        <button class="btn primary" data-action="export-estimate-excel">⬇ Export Excel</button>
        <button class="btn primary" data-action="export-estimate-pdf">⬇ Export PDF</button>
      </div>
      <table class="report-table">
        <thead><tr><th>S.No</th><th>Description</th><th>Unit</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead>
        <tbody>
    `;
    for (const cat of estimate.categories) {
      html += `<tr class="cat-row"><td colspan="6">${cat.code} — ${App.escapeHtml(cat.name)}</td></tr>`;
      for (const it of cat.items) {
        html += `<tr><td>${App.escapeHtml(it.sNo)}</td><td>${App.escapeHtml(it.description)}</td><td>${App.escapeHtml(it.unit)}</td><td>${Calc.fmt(it.quantity)}</td><td>${Calc.fmt(it.rate)}</td><td>${Calc.fmt(it.amount)}</td></tr>`;
      }
      html += `<tr class="subtotal-row"><td colspan="5">Total ${App.escapeHtml(cat.name)}</td><td>${Calc.fmt(cat.subtotal)}</td></tr>`;
    }
    html += `
        </tbody>
        <tfoot>
          <tr><td colspan="5">Sub Total</td><td>${Calc.fmt(estimate.subTotal)}</td></tr>
          <tr><td colspan="5">VAT @ ${estimate.vatPercent}%</td><td>${Calc.fmt(estimate.vatAmount)}</td></tr>
          <tr class="grand-row"><td colspan="5">Grand Total (with VAT)</td><td>${Calc.fmt(estimate.totalWithVat)}</td></tr>
        </tfoot>
      </table>
    `;
    return html;
  },

  // ---------------- WPR tab ----------------
  async renderWprTab(project) {
    const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
    const measurements = await DB.getAllByIndex("measurements", "projectId", project.id);
    const billNo = App.state.wprBillNo || project.billNo;
    const wpr = Calc.buildWPR(project, boqItems, measurements, billNo);

    let html = `
      <div class="row-actions">
        <label class="inline-label">Bill No
          <input type="number" min="1" value="${billNo}" id="wprBillInput" data-action="set-wpr-bill" style="width:70px">
        </label>
        <button class="btn primary" data-action="export-wpr-excel">⬇ Export Excel</button>
        <button class="btn primary" data-action="export-wpr-pdf">⬇ Export PDF</button>
      </div>
      <table class="report-table small-font">
        <thead><tr><th>S.No</th><th>Description</th><th>Unit</th><th>Rate</th><th>Upto Qty</th><th>Upto Amt</th><th>Prev Qty</th><th>Prev Amt</th><th>This Qty</th><th>This Amt</th></tr></thead>
        <tbody>
          ${wpr.rows
            .map(
              (r) => `
            <tr>
              <td>${App.escapeHtml(r.sNo)}</td><td>${App.escapeHtml(r.description)}</td><td>${App.escapeHtml(r.unit)}</td><td>${Calc.fmt(r.rate)}</td>
              <td>${Calc.fmt(r.uptoQty)}</td><td>${Calc.fmt(r.uptoAmt)}</td>
              <td>${Calc.fmt(r.prevQty)}</td><td>${Calc.fmt(r.prevAmt)}</td>
              <td>${Calc.fmt(r.thisQty)}</td><td>${Calc.fmt(r.thisAmt)}</td>
            </tr>`
            )
            .join("")}
        </tbody>
        <tfoot>
          <tr><td colspan="5">Sub Total</td><td>${Calc.fmt(wpr.totals.upto)}</td><td></td><td>${Calc.fmt(wpr.totals.prev)}</td><td></td><td>${Calc.fmt(wpr.totals.thisBill)}</td></tr>
          <tr><td colspan="5">VAT @ ${wpr.vatPercent}%</td><td>${Calc.fmt(wpr.totals.uptoVat)}</td><td></td><td>${Calc.fmt(wpr.totals.prevVat)}</td><td></td><td>${Calc.fmt(wpr.totals.thisVat)}</td></tr>
          <tr class="grand-row"><td colspan="5">Total with VAT</td><td>${Calc.fmt(wpr.totals.uptoWithVat)}</td><td></td><td>${Calc.fmt(wpr.totals.prevWithVat)}</td><td></td><td>${Calc.fmt(wpr.totals.thisWithVat)}</td></tr>
        </tfoot>
      </table>
    `;
    return html;
  },

  // ---------------- Photos overview tab ----------------
  async renderPhotosTab(project) {
    const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
    const photos = await DB.getAllByIndex("photos", "projectId", project.id);
    let html = `
      <div class="row-actions">
        <button class="btn primary" data-action="export-photo-report">⬇ Export Photo Report (PDF)</button>
      </div>
    `;
    const itemsWithPhotos = boqItems.filter((it) => photos.some((p) => p.boqItemId === it.id));
    if (itemsWithPhotos.length === 0) html += '<p class="muted">No photos recorded yet. Add them from the BOQ & Measurements tab.</p>';
    for (const item of itemsWithPhotos) {
      const itemPhotos = photos.filter((p) => p.boqItemId === item.id);
      html += `<h3 class="cat-header">${App.escapeHtml(item.sNo)} ${App.escapeHtml(item.description)}</h3><div class="photo-row">`;
      for (const stage of ["before", "during", "after"]) {
        const p = itemPhotos.filter((ph) => ph.stage === stage);
        html += `<div class="photo-slot"><div class="photo-slot-label">${stage}</div><div class="photo-thumbs">${p.map((ph) => `<img class="thumb" src="${Camera.blobToObjectUrl(ph.blob)}">`).join("") || '<span class="muted small">none</span>'}</div></div>`;
      }
      html += `</div>`;
    }
    return html;
  },

  // ---------------- Letterhead Settings ----------------
  async renderLetterhead() {
    App.state.view = "letterhead";
    const lh = await DB.getLetterhead();
    document.getElementById("app").innerHTML = `
      <div class="topbar"><button class="btn" data-action="go-home">← Back</button><h1>Letterhead Settings</h1></div>
      <div class="content">
        <p class="muted">Used on all Excel and PDF exports. Stored on this device only.</p>
        <form data-form="letterhead">
          <label>Office Name<input name="officeName" value="${App.escapeHtml(lh.officeName || "")}"></label>
          <label>Subtitle<input name="officeSubtitle" value="${App.escapeHtml(lh.officeSubtitle || "")}"></label>
          <label>Address<input name="address" value="${App.escapeHtml(lh.address || "")}"></label>
          <label>Province / Region<input name="province" value="${App.escapeHtml(lh.province || "")}"></label>
          <label>Footer Note<input name="footerNote" value="${App.escapeHtml(lh.footerNote || "")}"></label>
          <label>Logo Image
            <input name="logo" type="file" accept="image/*">
          </label>
          ${lh.logoBlob ? `<img src="${Camera.blobToObjectUrl(lh.logoBlob)}" style="max-width:80px;display:block;margin:8px 0;">` : ""}
          <button class="btn primary" type="submit">Save Letterhead</button>
        </form>
      </div>
    `;
  },

  // ============================================================
  // EVENT HANDLERS
  // ============================================================
  async handleClick(e) {
    const el = e.target.closest("[data-action]");
    if (!el) return;
    const action = el.dataset.action;

    if (action === "new-project") return App.renderNewProjectForm();
    if (action === "go-home") return App.renderHome();
    if (action === "open-letterhead") return App.renderLetterhead();
    if (action === "open-project") {
      App.state.currentProjectId = el.dataset.id;
      App.state.activeTab = "boq";
      App.state.expandedBoqItemId = null;
      App.state.wprBillNo = null;
      return App.renderProject();
    }
    if (action === "delete-project") {
      e.stopPropagation();
      if (!confirm("Delete this project and all its measurements/photos? This cannot be undone.")) return;
      await DB.deleteProjectCascade(el.dataset.id);
      return App.renderHome();
    }
    if (action === "set-tab") {
      App.state.activeTab = el.dataset.tab;
      App.state.expandedBoqItemId = null;
      return App.renderProject();
    }
    if (action === "toggle-boq-item") {
      App.state.expandedBoqItemId = App.state.expandedBoqItemId === el.dataset.id ? null : el.dataset.id;
      return App.renderProject();
    }
    if (action === "add-boq-item") return App.renderBoqItemForm(App.state.currentProjectId, null);
    if (action === "edit-boq-item") return App.renderBoqItemForm(App.state.currentProjectId, el.dataset.id);
    if (action === "delete-boq-item") {
      if (!confirm("Delete this BOQ item and all its measurements/photos?")) return;
      const meas = await DB.getAllByIndex("measurements", "boqItemId", el.dataset.id);
      const photos = await DB.getAllByIndex("photos", "boqItemId", el.dataset.id);
      await Promise.all([...meas.map((m) => DB.delete("measurements", m.id)), ...photos.map((p) => DB.delete("photos", p.id))]);
      await DB.delete("boqItems", el.dataset.id);
      return App.renderProject();
    }
    if (action === "add-measurement") return App.renderMeasurementForm(el.dataset.id, null);
    if (action === "edit-measurement") {
      const m = await DB.get("measurements", el.dataset.id);
      return App.renderMeasurementForm(m.boqItemId, m.id);
    }
    if (action === "delete-measurement") {
      if (!confirm("Delete this measurement entry?")) return;
      await DB.delete("measurements", el.dataset.id);
      return App.renderProject();
    }
    if (action === "back-to-boq") {
      App.state.activeTab = "boq";
      return App.renderProject();
    }
    if (action === "add-row") {
      const tbody = document.querySelector("#rowsTable tbody");
      tbody.insertAdjacentHTML("beforeend", App.rowHtml({ id: DB.uid("row"), particular: "", length: "", breadth: "", height: "", no: "" }));
      return App.recalcRowsTotal();
    }
    if (action === "remove-row") {
      el.closest("tr").remove();
      return App.recalcRowsTotal();
    }
    if (action === "take-photo") {
      const boqItemId = el.dataset.id;
      const stage = el.dataset.stage;
      const originalLabel = el.textContent;
      try {
        el.disabled = true;
        el.textContent = "Opening camera…";
        const blob = await Camera.capture();
        const boqItem = await DB.get("boqItems", boqItemId);
        await DB.savePhoto({ projectId: boqItem.projectId, boqItemId, measurementId: null, stage, blob });
        await App.renderProject();
      } catch (err) {
        console.warn(err);
        el.disabled = false;
        el.textContent = originalLabel;
      }
      return;
    }
    if (action === "delete-photo") {
      if (!confirm("Delete this photo?")) return;
      await DB.delete("photos", el.dataset.id);
      return App.renderProject();
    }
    if (action === "export-estimate-excel" || action === "export-estimate-pdf") {
      const project = await DB.get("projects", App.state.currentProjectId);
      const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
      const measurements = await DB.getAllByIndex("measurements", "projectId", project.id);
      const estimate = Calc.buildEstimate(project, boqItems, measurements, project.billNo);
      const letterhead = await DB.getLetterhead();
      if (action === "export-estimate-excel") await Exporter.exportEstimateExcel(project, estimate, letterhead);
      else await Exporter.exportEstimatePDF(project, estimate, letterhead);
      return;
    }
    if (action === "export-wpr-excel" || action === "export-wpr-pdf") {
      const project = await DB.get("projects", App.state.currentProjectId);
      const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
      const measurements = await DB.getAllByIndex("measurements", "projectId", project.id);
      const billNo = App.state.wprBillNo || project.billNo;
      const wpr = Calc.buildWPR(project, boqItems, measurements, billNo);
      const letterhead = await DB.getLetterhead();
      if (action === "export-wpr-excel") await Exporter.exportWPRExcel(project, wpr, letterhead, billNo);
      else await Exporter.exportWPRPDF(project, wpr, letterhead, billNo);
      return;
    }
    if (action === "export-photo-report") {
      const project = await DB.get("projects", App.state.currentProjectId);
      const boqItems = (await DB.getAllByIndex("boqItems", "projectId", project.id)).sort((a, b) => a.order - b.order);
      const photos = await DB.getAllByIndex("photos", "projectId", project.id);
      const photosByItem = {};
      for (const p of photos) {
        photosByItem[p.boqItemId] = photosByItem[p.boqItemId] || [];
        photosByItem[p.boqItemId].push(p);
      }
      const letterhead = await DB.getLetterhead();
      await Exporter.exportPhotoReportPDF(project, boqItems, photosByItem, letterhead);
      return;
    }
  },

  async renderBoqItemForm(projectId, itemId) {
    const item = itemId ? await DB.get("boqItems", itemId) : null;
    document.getElementById("app").innerHTML = `
      <div class="topbar"><button class="btn" data-action="back-to-boq">← Back</button><h1>${item ? "Edit" : "Add"} BOQ Item</h1></div>
      <div class="content">
        <form data-form="boq-item" data-project-id="${projectId}" data-item-id="${itemId || ""}">
          <label>Category Code (A, B, C...)<input name="categoryCode" value="${item ? App.escapeHtml(item.categoryCode) : "B"}"></label>
          <label>Category Name<input name="categoryName" value="${item ? App.escapeHtml(item.categoryName) : "Civil Works"}"></label>
          <label>S.No<input name="sNo" value="${item ? App.escapeHtml(item.sNo) : ""}" placeholder="e.g. 1.0"></label>
          <label>Description<textarea name="description" required>${item ? App.escapeHtml(item.description) : ""}</textarea></label>
          <label>Unit<input name="unit" value="${item ? App.escapeHtml(item.unit) : ""}" placeholder="Cum, Sqm, Kg, no..."></label>
          <label>Rate<input name="rate" type="number" step="any" value="${item ? item.rate : ""}"></label>
          <label class="checkbox-row"><input type="checkbox" name="isLumpSum" ${item && item.isLumpSum ? "checked" : ""}> Lump sum / Provisional Sum item (quantity fixed at 1)</label>
          <button class="btn primary" type="submit">Save Item</button>
        </form>
      </div>
    `;
  },

  async handleSubmit(e) {
    e.preventDefault();
    const form = e.target.closest("form");
    if (!form) return;
    const formType = form.dataset.form;

    if (formType === "new-project") return App.createProjectFromForm(form);

    if (formType === "edit-project") {
      const fd = new FormData(form);
      const project = await DB.get("projects", App.state.currentProjectId);
      Object.assign(project, {
        name: fd.get("name"),
        location: fd.get("location"),
        contractId: fd.get("contractId"),
        contractorName: fd.get("contractorName"),
        agreementDate: fd.get("agreementDate"),
        workOrderDate: fd.get("workOrderDate"),
        completionDate: fd.get("completionDate"),
        billNo: fd.get("billNo"),
        vatPercent: parseFloat(fd.get("vatPercent")) || 13
      });
      await DB.updateProject(project);
      return App.renderProject();
    }

    if (formType === "boq-item") {
      const fd = new FormData(form);
      const projectId = form.dataset.projectId;
      const itemId = form.dataset.itemId;
      const data = {
        categoryCode: fd.get("categoryCode") || "B",
        categoryName: fd.get("categoryName") || "Civil Works",
        sNo: fd.get("sNo"),
        description: fd.get("description"),
        unit: fd.get("unit"),
        rate: fd.get("rate"),
        isLumpSum: !!fd.get("isLumpSum")
      };
      if (itemId) {
        const existing = await DB.get("boqItems", itemId);
        Object.assign(existing, data, { rate: parseFloat(data.rate) || 0 });
        await DB.put("boqItems", existing);
      } else {
        await DB.addBoqItem(projectId, data);
      }
      App.state.activeTab = "boq";
      return App.renderProject();
    }

    if (formType === "measurement") {
      const fd = new FormData(form);
      const boqItemId = form.dataset.boqId;
      const measId = form.dataset.measId;
      const item = await DB.get("boqItems", boqItemId);
      let rows = [];
      if (!item.isLumpSum) {
        document.querySelectorAll("#rowsTable tbody tr").forEach((tr) => {
          rows.push({
            id: tr.dataset.rowId,
            particular: tr.querySelector('[data-f="particular"]').value,
            length: tr.querySelector('[data-f="length"]').value,
            breadth: tr.querySelector('[data-f="breadth"]').value,
            height: tr.querySelector('[data-f="height"]').value,
            no: tr.querySelector('[data-f="no"]').value
          });
        });
        rows = Calc.computeRows(rows).rows;
      }
      await DB.saveMeasurement({
        id: measId || undefined,
        projectId: item.projectId,
        boqItemId,
        billNo: fd.get("billNo"),
        label: fd.get("label"),
        rows,
        remarks: fd.get("remarks"),
        isLumpSum: item.isLumpSum
      });
      App.state.activeTab = "boq";
      App.state.expandedBoqItemId = boqItemId;
      return App.renderProject();
    }

    if (formType === "letterhead") {
      const fd = new FormData(form);
      const lh = await DB.getLetterhead();
      lh.officeName = fd.get("officeName");
      lh.officeSubtitle = fd.get("officeSubtitle");
      lh.address = fd.get("address");
      lh.province = fd.get("province");
      lh.footerNote = fd.get("footerNote");
      const logoFile = fd.get("logo");
      if (logoFile && logoFile.size > 0) {
        lh.logoBlob = await Camera.compress(logoFile, 300, 0.85);
      }
      await DB.saveLetterhead(lh);
      return App.renderHome();
    }
  },

  handleChange(e) {
    if (e.target.matches("#rowsTable .cell")) return App.recalcRowsTotal();
    if (e.target.id === "wprBillInput") {
      const val = parseInt(e.target.value, 10);
      App.state.wprBillNo = val > 0 ? val : 1;
      return App.renderProject();
    }
  }
};

window.addEventListener("DOMContentLoaded", App.init);
