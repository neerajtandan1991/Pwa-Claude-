/**
 * Photo capture helper.
 * Uses <input type="file" accept="image/*" capture="environment"> which
 * opens the phone's native camera app directly — this works fully
 * offline (no getUserMedia/HTTPS-only complications) and is the most
 * reliable approach across Android/iOS home-screen PWAs.
 * Images are downscaled/compressed client-side before being stored in
 * IndexedDB, to keep offline storage usage reasonable.
 */

const Camera = {
  /** Opens the native camera (or gallery) and resolves with a compressed JPEG Blob */
  capture() {
    return new Promise((resolve, reject) => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.capture = "environment";
      input.style.display = "none";
      document.body.appendChild(input);

      input.onchange = async () => {
        const file = input.files && input.files[0];
        document.body.removeChild(input);
        if (!file) return reject(new Error("No photo captured"));
        try {
          const compressed = await Camera.compress(file);
          resolve(compressed);
        } catch (e) {
          reject(e);
        }
      };
      input.onclick = () => {
        // allow re-selecting the same photo triggering onchange reliably
        input.value = "";
      };
      document.body.appendChild(input);
      input.click();
    });
  },

  compress(file, maxDim = 1280, quality = 0.72) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(
          (blob) => {
            URL.revokeObjectURL(url);
            if (blob) resolve(blob);
            else reject(new Error("Compression failed"));
          },
          "image/jpeg",
          quality
        );
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("Could not load image"));
      };
      img.src = url;
    });
  },

  blobToObjectUrl(blob) {
    return URL.createObjectURL(blob);
  }
};

window.Camera = Camera;
