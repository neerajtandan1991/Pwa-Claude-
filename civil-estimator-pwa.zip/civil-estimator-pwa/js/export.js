/**
 * Export engine — Excel (SheetJS) and PDF (jsPDF + AutoTable) with a
 * customizable letterhead (office name/address/logo, editable in Settings).
 * Both libraries are loaded via CDN <script> tags in index.html and are
 * cached by the service worker after first load, so exports keep working
 * offline once the app has been opened online at least once.
 */

const Exporter = {
  async blobToDataUrl(blob) {
    if (!blob) return null;
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  },

  // ---------------- EXCEL ----------------

  async exportEstimateExcel(project, estimate, letterhead) {
    const wb = XLSX.utils.book_new();
    const rows = [];

    rows.push([letterhead.officeName || ""]);
    if (letterhead.officeSubtitle) rows.push([letterhead.officeSubtitle]);
    if (letterhead.address) rows.push([letterhead.address]);
    if (letterhead.province) rows.push([letterhead.province]);
    rows.push([]);
    rows.push(["Estimate / Measurement Book"]);
    rows.push(["Project Name:", project.name, "", "", "Contract ID:", project.contractId]);
    rows.push(["Location:", project.location, "", "", "Contractor:", project.contractorName]);
    rows.push(["Agreement Date:", project.agreementDate, "", "", "Work Order Date:", project.workOrderDate]);
    rows.push(["Bill No:", project.billNo, "", "", "Completion Date:", project.completionDate]);
    rows.push([]);
    rows.push(["S.No", "Description of Work", "Unit", "Quantity", "Rate", "Amount"]);

    for (const cat of estimate.categories) {
      rows.push([cat.code, cat.name]);
      for (const it of cat.items) {
        rows.push([it.sNo, it.description, it.unit, it.quantity, it.rate, it.amount]);
      }
      rows.push(["", `Total ${cat.name}`, "", "", "", cat.subtotal]);
      rows.push([]);
    }

    rows.push(["", "Sub Total", "", "", "", estimate.subTotal]);
    rows.push(["", `VAT @ ${estimate.vatPercent}%`, "", "", "", estimate.vatAmount]);
    rows.push(["", "Grand Total (with VAT)", "", "", "", estimate.totalWithVat]);
    rows.push([]);
    rows.push(["Contractor's Signature", "", "Prepared by", "", "Checked by", "Approved by"]);

    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws["!cols"] = [{ wch: 8 }, { wch: 55 }, { wch: 8 }, { wch: 12 }, { wch: 12 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, ws, "Estimate");
    XLSX.writeFile(wb, `Estimate_${project.name.replace(/[^a-z0-9]/gi, "_")}_Bill${project.billNo}.xlsx`);
  },

  async exportWPRExcel(project, wpr, letterhead, billNo) {
    const wb = XLSX.utils.book_new();
    const rows = [];

    rows.push([letterhead.officeName || ""]);
    if (letterhead.address) rows.push([letterhead.address]);
    rows.push([]);
    rows.push(["Work Progress Report (IPC)"]);
    rows.push(["Project Name:", project.name, "", "", "Contract ID:", project.contractId]);
    rows.push(["Contractor:", project.contractorName, "", "", "Bill Serial No:", billNo]);
    rows.push([]);
    rows.push([
      "S.No", "Description", "Unit", "Rate",
      "Upto Date Qty", "Upto Date Amt",
      "Previous Bill Qty", "Previous Bill Amt",
      "This Bill Qty", "This Bill Amt"
    ]);

    for (const r of wpr.rows) {
      rows.push([
        r.sNo, r.description, r.unit, r.rate,
        r.uptoQty, r.uptoAmt,
        r.prevQty, r.prevAmt,
        r.thisQty, r.thisAmt
      ]);
    }

    rows.push([]);
    rows.push(["", "Sub Total", "", "", "", wpr.totals.upto, "", wpr.totals.prev, "", wpr.totals.thisBill]);
    rows.push(["", `VAT @ ${wpr.vatPercent}%`, "", "", "", wpr.totals.uptoVat, "", wpr.totals.prevVat, "", wpr.totals.thisVat]);
    rows.push(["", "Total with VAT", "", "", "", wpr.totals.uptoWithVat, "", wpr.totals.prevWithVat, "", wpr.totals.thisWithVat]);

    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws["!cols"] = [{ wch: 8 }, { wch: 45 }, { wch: 8 }, { wch: 10 }, { wch: 10 }, { wch: 14 }, { wch: 10 }, { wch: 14 }, { wch: 10 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, ws, "WPR");
    XLSX.writeFile(wb, `WPR_${project.name.replace(/[^a-z0-9]/gi, "_")}_Bill${billNo}.xlsx`);
  },

  // ---------------- PDF ----------------

  async addLetterheadToPDF(doc, letterhead) {
    let y = 12;
    if (letterhead.logoBlob) {
      try {
        const dataUrl = await this.blobToDataUrl(letterhead.logoBlob);
        doc.addImage(dataUrl, "PNG", 14, 8, 20, 20);
      } catch (e) { /* ignore bad logo */ }
    }
    doc.setFontSize(14);
    doc.setFont(undefined, "bold");
    doc.text(letterhead.officeName || "", 105, y, { align: "center" });
    y += 6;
    doc.setFontSize(10);
    doc.setFont(undefined, "normal");
    if (letterhead.officeSubtitle) { doc.text(letterhead.officeSubtitle, 105, y, { align: "center" }); y += 5; }
    if (letterhead.address) { doc.text(letterhead.address, 105, y, { align: "center" }); y += 5; }
    if (letterhead.province) { doc.text(letterhead.province, 105, y, { align: "center" }); y += 5; }
    doc.setLineWidth(0.5);
    doc.line(14, y + 2, 196, y + 2);
    return y + 8;
  },

  async exportEstimatePDF(project, estimate, letterhead) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
    let y = await this.addLetterheadToPDF(doc, letterhead);

    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text("Estimate / Measurement Book", 148.5, y, { align: "center" });
    y += 6;

    doc.setFontSize(9);
    doc.setFont(undefined, "normal");
    doc.text(`Project: ${project.name}`, 14, y);
    doc.text(`Contract ID: ${project.contractId || "-"}`, 150, y);
    y += 5;
    doc.text(`Location: ${project.location || "-"}`, 14, y);
    doc.text(`Contractor: ${project.contractorName || "-"}`, 150, y);
    y += 5;
    doc.text(`Bill No: ${project.billNo}`, 14, y);
    doc.text(`Work Order Date: ${project.workOrderDate || "-"}`, 150, y);
    y += 3;

    const body = [];
    for (const cat of estimate.categories) {
      body.push([{ content: `${cat.code}  ${cat.name}`, colSpan: 6, styles: { fontStyle: "bold", fillColor: [230, 230, 230] } }]);
      for (const it of cat.items) {
        body.push([it.sNo, it.description, it.unit, Calc.fmt(it.quantity), Calc.fmt(it.rate), Calc.fmt(it.amount)]);
      }
      body.push([{ content: `Total ${cat.name}`, colSpan: 5, styles: { fontStyle: "bold", halign: "right" } }, { content: Calc.fmt(cat.subtotal), styles: { fontStyle: "bold" } }]);
    }

    doc.autoTable({
      startY: y + 2,
      head: [["S.No", "Description of Work", "Unit", "Quantity", "Rate", "Amount"]],
      body,
      styles: { fontSize: 8, cellPadding: 1.5 },
      headStyles: { fillColor: [30, 58, 95] },
      columnStyles: { 1: { cellWidth: 110 } },
      margin: { left: 14, right: 14 }
    });

    let finalY = doc.lastAutoTable.finalY + 4;
    doc.setFontSize(9);
    doc.text(`Sub Total: ${Calc.fmt(estimate.subTotal)}`, 196, finalY, { align: "right" });
    finalY += 5;
    doc.text(`VAT @ ${estimate.vatPercent}%: ${Calc.fmt(estimate.vatAmount)}`, 196, finalY, { align: "right" });
    finalY += 5;
    doc.setFont(undefined, "bold");
    doc.text(`Grand Total (with VAT): ${Calc.fmt(estimate.totalWithVat)}`, 196, finalY, { align: "right" });

    if (letterhead.footerNote) {
      doc.setFontSize(8);
      doc.setFont(undefined, "italic");
      doc.text(letterhead.footerNote, 14, 205);
    }

    doc.save(`Estimate_${project.name.replace(/[^a-z0-9]/gi, "_")}_Bill${project.billNo}.pdf`);
  },

  async exportWPRPDF(project, wpr, letterhead, billNo) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
    let y = await this.addLetterheadToPDF(doc, letterhead);

    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text("Work Progress Report (IPC)", 148.5, y, { align: "center" });
    y += 6;

    doc.setFontSize(9);
    doc.setFont(undefined, "normal");
    doc.text(`Project: ${project.name}`, 14, y);
    doc.text(`Bill Serial No: ${billNo}`, 150, y);
    y += 5;
    doc.text(`Contractor: ${project.contractorName || "-"}`, 14, y);
    doc.text(`Contract ID: ${project.contractId || "-"}`, 150, y);

    const body = wpr.rows.map((r) => [
      r.sNo, r.description, r.unit, Calc.fmt(r.rate),
      Calc.fmt(r.uptoQty), Calc.fmt(r.uptoAmt),
      Calc.fmt(r.prevQty), Calc.fmt(r.prevAmt),
      Calc.fmt(r.thisQty), Calc.fmt(r.thisAmt)
    ]);

    doc.autoTable({
      startY: y + 4,
      head: [["S.No", "Description", "Unit", "Rate", "Upto Qty", "Upto Amt", "Prev Qty", "Prev Amt", "This Qty", "This Amt"]],
      body,
      styles: { fontSize: 7, cellPadding: 1.2 },
      headStyles: { fillColor: [30, 58, 95] },
      columnStyles: { 1: { cellWidth: 70 } },
      margin: { left: 14, right: 14 },
      foot: [[
        { content: "Totals", colSpan: 4, styles: { fontStyle: "bold" } },
        Calc.fmt(wpr.totals.upto), "",
        Calc.fmt(wpr.totals.prev), "",
        Calc.fmt(wpr.totals.thisBill), ""
      ]]
    });

    doc.save(`WPR_${project.name.replace(/[^a-z0-9]/gi, "_")}_Bill${billNo}.pdf`);
  },

  /** Photo evidence report: before/during/after photos grouped by BOQ item */
  async exportPhotoReportPDF(project, boqItems, photosByItem, letterhead) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    let y = await this.addLetterheadToPDF(doc, letterhead);
    doc.setFontSize(12);
    doc.setFont(undefined, "bold");
    doc.text("Photographic Progress Evidence", 105, y, { align: "center" });
    y += 8;

    for (const item of boqItems) {
      const photos = photosByItem[item.id] || [];
      if (photos.length === 0) continue;
      if (y > 250) { doc.addPage(); y = 15; }
      doc.setFontSize(10);
      doc.setFont(undefined, "bold");
      doc.text(`${item.sNo}  ${item.description}`.slice(0, 100), 14, y);
      y += 5;

      const stages = ["before", "during", "after"];
      let x = 14;
      const imgW = 58, imgH = 44;
      for (const stage of stages) {
        const p = photos.find((ph) => ph.stage === stage);
        doc.setFontSize(8);
        doc.setFont(undefined, "normal");
        doc.text(stage.toUpperCase(), x, y);
        if (p && p.blob) {
          try {
            const dataUrl = await this.blobToDataUrl(p.blob);
            doc.addImage(dataUrl, "JPEG", x, y + 1, imgW, imgH);
          } catch (e) {
            doc.rect(x, y + 1, imgW, imgH);
          }
        } else {
          doc.rect(x, y + 1, imgW, imgH);
          doc.text("(no photo)", x + 15, y + 24);
        }
        x += imgW + 4;
      }
      y += imgH + 12;
    }

    doc.save(`PhotoReport_${project.name.replace(/[^a-z0-9]/gi, "_")}.pdf`);
  }
};

window.Exporter = Exporter;
