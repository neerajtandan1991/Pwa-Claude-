/**
 * IndexedDB data layer — fully offline, all data stays on-device.
 * DB: CivilEstimatorDB
 * Stores:
 *   projects        { id, name, location, contractId, contractorName,
 *                      agreementDate, workOrderDate, completionDate,
 *                      billNo, mbNo, vatPercent, createdAt, updatedAt }
 *   boqItems        { id, projectId, categoryCode, categoryName, sNo,
 *                      description, unit, rate, isLumpSum, order }
 *   measurements     { id, projectId, boqItemId, billNo, label, rows:[
 *                        {id, particular, length, breadth, height, no, qty}
 *                      ], quantity, remarks, createdAt, updatedAt }
 *   photos          { id, projectId, boqItemId, measurementId, stage
 *                      ('before'|'during'|'after'), blob, caption,
 *                      takenAt, lat, lng }
 *   settings        { id: 'letterhead', officeName, officeSubtitle,
 *                      address, province, logoBlob, footerNote }
 */

const DB_NAME = "CivilEstimatorDB";
const DB_VERSION = 1;

let _dbInstance = null;

function openDB() {
  if (_dbInstance) return Promise.resolve(_dbInstance);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("projects")) {
        const s = db.createObjectStore("projects", { keyPath: "id" });
        s.createIndex("updatedAt", "updatedAt");
      }
      if (!db.objectStoreNames.contains("boqItems")) {
        const s = db.createObjectStore("boqItems", { keyPath: "id" });
        s.createIndex("projectId", "projectId");
      }
      if (!db.objectStoreNames.contains("measurements")) {
        const s = db.createObjectStore("measurements", { keyPath: "id" });
        s.createIndex("projectId", "projectId");
        s.createIndex("boqItemId", "boqItemId");
      }
      if (!db.objectStoreNames.contains("photos")) {
        const s = db.createObjectStore("photos", { keyPath: "id" });
        s.createIndex("projectId", "projectId");
        s.createIndex("boqItemId", "boqItemId");
        s.createIndex("measurementId", "measurementId");
      }
      if (!db.objectStoreNames.contains("settings")) {
        db.createObjectStore("settings", { keyPath: "id" });
      }
    };
    req.onsuccess = (e) => {
      _dbInstance = e.target.result;
      resolve(_dbInstance);
    };
    req.onerror = (e) => reject(e.target.error);
  });
}

function tx(storeName, mode = "readonly") {
  return openDB().then((db) => db.transaction(storeName, mode).objectStore(storeName));
}

function uid(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

const DB = {
  uid,

  // ---------- generic helpers ----------
  put(storeName, obj) {
    return tx(storeName, "readwrite").then(
      (store) =>
        new Promise((resolve, reject) => {
          const r = store.put(obj);
          r.onsuccess = () => resolve(obj);
          r.onerror = (e) => reject(e.target.error);
        })
    );
  },
  get(storeName, id) {
    return tx(storeName).then(
      (store) =>
        new Promise((resolve, reject) => {
          const r = store.get(id);
          r.onsuccess = () => resolve(r.result || null);
          r.onerror = (e) => reject(e.target.error);
        })
    );
  },
  delete(storeName, id) {
    return tx(storeName, "readwrite").then(
      (store) =>
        new Promise((resolve, reject) => {
          const r = store.delete(id);
          r.onsuccess = () => resolve(true);
          r.onerror = (e) => reject(e.target.error);
        })
    );
  },
  getAll(storeName) {
    return tx(storeName).then(
      (store) =>
        new Promise((resolve, reject) => {
          const r = store.getAll();
          r.onsuccess = () => resolve(r.result || []);
          r.onerror = (e) => reject(e.target.error);
        })
    );
  },
  getAllByIndex(storeName, indexName, value) {
    return tx(storeName).then(
      (store) =>
        new Promise((resolve, reject) => {
          const idx = store.index(indexName);
          const r = idx.getAll(value);
          r.onsuccess = () => resolve(r.result || []);
          r.onerror = (e) => reject(e.target.error);
        })
    );
  },

  // ---------- domain helpers ----------
  async createProject(data) {
    const now = new Date().toISOString();
    const project = {
      id: uid("proj"),
      name: data.name || "Untitled Project",
      location: data.location || "",
      contractId: data.contractId || "",
      contractorName: data.contractorName || "",
      agreementDate: data.agreementDate || "",
      workOrderDate: data.workOrderDate || "",
      completionDate: data.completionDate || "",
      billNo: data.billNo || "1",
      mbNo: data.mbNo || "1",
      vatPercent: data.vatPercent != null ? data.vatPercent : 13,
      createdAt: now,
      updatedAt: now
    };
    await DB.put("projects", project);
    return project;
  },

  async updateProject(project) {
    project.updatedAt = new Date().toISOString();
    return DB.put("projects", project);
  },

  async deleteProjectCascade(projectId) {
    const [boq, meas, photos] = await Promise.all([
      DB.getAllByIndex("boqItems", "projectId", projectId),
      DB.getAllByIndex("measurements", "projectId", projectId),
      DB.getAllByIndex("photos", "projectId", projectId)
    ]);
    await Promise.all([
      ...boq.map((b) => DB.delete("boqItems", b.id)),
      ...meas.map((m) => DB.delete("measurements", m.id)),
      ...photos.map((p) => DB.delete("photos", p.id))
    ]);
    return DB.delete("projects", projectId);
  },

  async seedBoqFromTemplate(projectId, template) {
    const items = [];
    let order = 0;
    for (const cat of template.categories) {
      for (const it of cat.items) {
        order++;
        items.push({
          id: uid("boq"),
          projectId,
          categoryCode: cat.code,
          categoryName: cat.name,
          sNo: it.sNo,
          description: it.description,
          unit: it.unit,
          rate: it.rate,
          isLumpSum: !!it.isLumpSum,
          order
        });
      }
    }
    await Promise.all(items.map((i) => DB.put("boqItems", i)));
    return items;
  },

  async addBoqItem(projectId, data, order) {
    const item = {
      id: uid("boq"),
      projectId,
      categoryCode: data.categoryCode || "B",
      categoryName: data.categoryName || "Civil Works",
      sNo: data.sNo || "",
      description: data.description || "",
      unit: data.unit || "",
      rate: parseFloat(data.rate) || 0,
      isLumpSum: !!data.isLumpSum,
      order: order != null ? order : Date.now()
    };
    await DB.put("boqItems", item);
    return item;
  },

  async saveMeasurement(data) {
    const now = new Date().toISOString();
    const rows = (data.rows || []).map((r) => ({
      id: r.id || uid("row"),
      particular: r.particular || "",
      length: r.length,
      breadth: r.breadth,
      height: r.height,
      no: r.no,
      qty: r.qty
    }));
    const quantity = rows.reduce((sum, r) => sum + (parseFloat(r.qty) || 0), 0);
    const record = {
      id: data.id || uid("meas"),
      projectId: data.projectId,
      boqItemId: data.boqItemId,
      billNo: data.billNo || "1",
      label: data.label || "",
      rows,
      quantity: data.isLumpSum ? 1 : quantity,
      remarks: data.remarks || "",
      createdAt: data.createdAt || now,
      updatedAt: now
    };
    await DB.put("measurements", record);
    return record;
  },

  async savePhoto({ projectId, boqItemId, measurementId, stage, blob, caption }) {
    const photo = {
      id: uid("photo"),
      projectId,
      boqItemId: boqItemId || null,
      measurementId: measurementId || null,
      stage, // 'before' | 'during' | 'after'
      blob,
      caption: caption || "",
      takenAt: new Date().toISOString()
    };
    await DB.put("photos", photo);
    return photo;
  },

  async getLetterhead() {
    const s = await DB.get("settings", "letterhead");
    return (
      s || {
        id: "letterhead",
        officeName: "Office of Municipal Executive",
        officeSubtitle: "",
        address: "",
        province: "",
        logoBlob: null,
        footerNote: ""
      }
    );
  },

  async saveLetterhead(data) {
    data.id = "letterhead";
    return DB.put("settings", data);
  }
};

window.DB = DB;
