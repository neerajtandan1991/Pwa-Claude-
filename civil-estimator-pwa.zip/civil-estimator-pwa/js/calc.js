/**
 * Calculation engine — plain JS re-implementation of the Measurement
 * Book / BOQ math (Length x Breadth x Height x No -> Qty), rebuilt
 * clean because the source workbooks had broken #REF!/#ERROR! chains.
 */

const Calc = {
  /** One measurement row: L x B x H x No (any blank dimension = 1, so
   * you can do L x B only, or L x No only, etc. Negative "No" = deduction) */
  rowQty(row) {
    const L = row.length !== "" && row.length != null ? parseFloat(row.length) : 1;
    const B = row.breadth !== "" && row.breadth != null ? parseFloat(row.breadth) : 1;
    const H = row.height !== "" && row.height != null ? parseFloat(row.height) : 1;
    const N = row.no !== "" && row.no != null ? parseFloat(row.no) : 1;
    if ([L, B, H, N].some((v) => Number.isNaN(v))) return 0;
    return L * B * H * N;
  },

  /** Recompute qty for every row in an array and return the sum */
  computeRows(rows) {
    const withQty = rows.map((r) => ({ ...r, qty: this.rowQty(r) }));
    const total = withQty.reduce((s, r) => s + r.qty, 0);
    return { rows: withQty, total };
  },

  /** Sum quantity across all measurements recorded for one BOQ item
   * (across multiple bills, since Nepal IPCs are cumulative "upto date") */
  upToDateQuantity(measurements, boqItemId, uptoBillNo, isLumpSum) {
    const relevant = measurements.filter(
      (m) => m.boqItemId === boqItemId && Number(m.billNo) <= Number(uptoBillNo)
    );
    if (isLumpSum) return relevant.length > 0 ? 1 : 0;
    return relevant.reduce((s, m) => s + (parseFloat(m.quantity) || 0), 0);
  },

  /** Quantity recorded specifically in one bill (not cumulative) */
  thisBillQuantity(measurements, boqItemId, billNo, isLumpSum) {
    const relevant = measurements.filter(
      (m) => m.boqItemId === boqItemId && String(m.billNo) === String(billNo)
    );
    if (isLumpSum) return relevant.length > 0 ? 1 : 0;
    return relevant.reduce((s, m) => s + (parseFloat(m.quantity) || 0), 0);
  },

  amount(qty, rate) {
    const q = parseFloat(qty) || 0;
    const r = parseFloat(rate) || 0;
    return q * r;
  },

  /** Build the full Estimate/IPC rollup for a project at a given bill number */
  buildEstimate(project, boqItems, measurements, uptoBillNo) {
    const categories = {};
    let grandTotal = 0;

    for (const item of boqItems) {
      const qty = this.upToDateQuantity(measurements, item.id, uptoBillNo, item.isLumpSum);
      const amt = this.amount(qty, item.rate);
      const catKey = item.categoryCode;
      if (!categories[catKey]) {
        categories[catKey] = { code: item.categoryCode, name: item.categoryName, items: [], subtotal: 0 };
      }
      categories[catKey].items.push({
        ...item,
        quantity: qty,
        amount: amt
      });
      categories[catKey].subtotal += amt;
      grandTotal += amt;
    }

    const catList = Object.values(categories).sort((a, b) => (a.code > b.code ? 1 : -1));
    const vatPercent = project.vatPercent != null ? project.vatPercent : 13;
    const vatAmount = grandTotal * (vatPercent / 100);
    const totalWithVat = grandTotal + vatAmount;

    return {
      categories: catList,
      subTotal: grandTotal,
      vatPercent,
      vatAmount,
      totalWithVat
    };
  },

  /** Build the Work Progress Report (WPR): per item, agreement qty (if
   * tracked), upto-date qty/amount, previous-bill qty/amount, this-bill
   * qty/amount, and remaining qty. */
  buildWPR(project, boqItems, measurements, currentBillNo) {
    const prevBillNo = Number(currentBillNo) - 1;
    const rows = [];
    let totals = { upto: 0, prev: 0, thisBill: 0 };

    for (const item of boqItems) {
      const uptoQty = this.upToDateQuantity(measurements, item.id, currentBillNo, item.isLumpSum);
      const prevQty = prevBillNo >= 1 ? this.upToDateQuantity(measurements, item.id, prevBillNo, item.isLumpSum) : 0;
      const thisQty = item.isLumpSum ? (uptoQty - prevQty > 0 ? 1 : 0) : uptoQty - prevQty;

      const uptoAmt = this.amount(uptoQty, item.rate);
      const prevAmt = this.amount(prevQty, item.rate);
      const thisAmt = this.amount(thisQty, item.rate);

      totals.upto += uptoAmt;
      totals.prev += prevAmt;
      totals.thisBill += thisAmt;

      rows.push({
        ...item,
        uptoQty,
        uptoAmt,
        prevQty,
        prevAmt,
        thisQty,
        thisAmt
      });
    }

    const vatPercent = project.vatPercent != null ? project.vatPercent : 13;
    return {
      rows,
      totals: {
        ...totals,
        uptoVat: totals.upto * (vatPercent / 100),
        prevVat: totals.prev * (vatPercent / 100),
        thisVat: totals.thisBill * (vatPercent / 100),
        uptoWithVat: totals.upto * (1 + vatPercent / 100),
        prevWithVat: totals.prev * (1 + vatPercent / 100),
        thisWithVat: totals.thisBill * (1 + vatPercent / 100)
      },
      vatPercent
    };
  },

  fmt(n) {
    const num = parseFloat(n) || 0;
    return num.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
};

window.Calc = Calc;
