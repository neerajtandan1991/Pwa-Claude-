/**
 * Default BOQ Template
 * Derived from: Construction of Ward Office Building, Ward No 2,
 * Gaindakot Municipality, Nawalpur (Contract 9/GM/NCB/2081-082)
 *
 * NOTE: The source estimate_sheet.xlsx / wpr.xlsx had broken cross-sheet
 * references (#REF!/#ERROR!) throughout — this template rebuilds the
 * item list and rates cleanly. Quantities are NOT pre-filled; they are
 * computed live from the measurement entries you add in the app.
 *
 * This is just a starting template — every field (description, unit,
 * rate, category) is editable in-app, and you can add/remove items,
 * or start a project from a completely blank BOQ.
 */

const DEFAULT_BOQ_TEMPLATE = {
  templateName: "Ward Office Building (Sample)",
  categories: [
    {
      code: "A",
      name: "Provisional Sum",
      items: [
        { sNo: "1.0", description: "Insurance of works, plants, materials, loss and damage to equipments, Contractor's workmen and employees and third party insurance against damage to other persons and property as per GCC clause 13.", unit: "PS", rate: 70000, isLumpSum: true },
        { sNo: "2.0", description: "Carry out additional tests for material and works as required and instructed by the Engineer (GCC Clause No. 33.1).", unit: "PS", rate: 50000, isLumpSum: true },
        { sNo: "3.0", description: "Provide and installation of project information board of size 1.80m x 1.2m along with iron posts including excavation, concreting, backfilling etc. all complete as per DoR SSRBW July 2001, Section-108.", unit: "PS", rate: 5000, isLumpSum: true }
      ]
    },
    {
      code: "B",
      name: "Civil Works",
      items: [
        { sNo: "1.0", description: "Site Clearance Works before and after construction work all complete.", unit: "Sqm", rate: 50 },
        { sNo: "2.0", description: "Earthwork in excavation including necessary backfilling after excavation in trenches, foundation etc. in all kinds of soil including dressing of sides, ramming of bottom, lift upto 1.5m, stacking of excavated materials at suitable location for future use (mechanical means).", unit: "Cum", rate: 180 },
        { sNo: "3.0", description: "Filling work within foundation area (approx. 50% of foundation excavation) with proper compaction in layers.", unit: "Cum", rate: 150 },
        { sNo: "4.0", description: "Boulder soiling including proper line and level, closely packed with sand for compaction wherever required as per design, drawing, specification and instruction of engineer.", unit: "Cum", rate: 2600 },
        { sNo: "5.0", description: "Plain Cement Concrete of grade M10 (1:3:6) in foundation including setting out, machine mixing, laying, compacting, curing, testing and finishing complete.", unit: "Cum", rate: 9500 },
        { sNo: "6.0", description: "Brick Masonry work with 1:4 mortar with supply of brick including cleaning, curing, necessary scaffolding all complete.", unit: "Cum", rate: 13000 },
        { sNo: "7.0", description: "12.5mm plaster (1:4) on the internal wall at proper line and level as per instruction of site engineer.", unit: "sq.m", rate: 300 },
        { sNo: "8.0", description: "12.5mm plaster (1:4) on the external wall at proper line and level as per instruction of site engineer.", unit: "sq.m", rate: 300 },
        { sNo: "9.0", description: "12.5mm plaster (1:3) on the ceiling at proper line and level as per instruction of site engineer.", unit: "sq.m", rate: 300 },
        { sNo: "10.0", description: "3mm fine cement punning work as per instruction of engineer.", unit: "sq.m", rate: 200 },
        { sNo: "11.0", description: "Plain Cement Concrete M25 (1:1:2) for all RCC/PCC work (except flooring) including setting out, machine mixing, laying, compacting, curing, testing and finishing complete.", unit: "Cum", rate: 12000 },
        { sNo: "12.0", description: "Plain Cement Concrete M20 (1:1.5:3) for all RCC/PCC work (except flooring) including setting out, machine mixing, laying, compacting, curing, testing and finishing complete.", unit: "Cum", rate: 11000 },
        { sNo: "13.0", description: "Plain Cement Concrete (1:2:4) for flooring work including setting out, machine mixing, laying, compacting, curing, testing and finishing complete.", unit: "Cum", rate: 10000 },
        { sNo: "14.0", description: "Steel reinforcement bar of Fe 415/500 grade including straightening, cleaning, cutting, bending, placing in position and binding with annealed binding wire all complete as per design, drawing and specification.", unit: "Kg", rate: 120 },
        { sNo: "15.0", description: "Form works for beam, column, slab, lintel and sill band with necessary props and supports made of 18mm plywood all complete.", unit: "Sq.m", rate: 500 },
        { sNo: "16.0", description: "Supply, installation of UPVC Door 100mmx60mm white colour with top glass 5mm and bottom UPVC panel all complete.", unit: "sq.m", rate: 6500 },
        { sNo: "17.0", description: "Supply and installation of UPVC sliding window with 50x80mm white colour and 5mm glass with aluminium sliding track all complete.", unit: "sq.m", rate: 6500 },
        { sNo: "18.0", description: "38mm concreting work in 1:2:4 ratio on floor including levelling, polishing and 3mm fine cement punning work all complete.", unit: "sq.m", rate: 400 },
        { sNo: "19.0", description: "Roof truss work.", unit: "KG", rate: 170 },
        { sNo: "20.0", description: "26(H) 0.41mm thick coloured C.G.I. sheet roofing work (65kg/bandal).", unit: "Sq.m", rate: 950 },
        { sNo: "21.0", description: "Laying of porcelain tile in 1:4 cement sand mortar over prepared wall/floor surface as per specification and instruction of engineer.", unit: "Sq.m", rate: 180 },
        { sNo: "22.0", description: "Sanitary work: Water Closet set complete (Hindware/Parryware/Somany/Cera or equivalent), porcelain clay white glaze one piece commode with P & S trap and slow falling seat cover.", unit: "Set", rate: 12000 },
        { sNo: "23.0", description: "Wash basin set complete, porcelain clay white glazed counter wash basin with mixer.", unit: "Set", rate: 7500 },
        { sNo: "24.0", description: "Fittings/valves: 15mm dia angle valve with wall flange.", unit: "no", rate: 1200 },
        { sNo: "25.0", description: "Fittings/valves: 15mm CP water spray with 1.2m long flexible pipe.", unit: "no", rate: 1200 },
        { sNo: "26.0", description: "Fittings/valves: C.P. bibcock 15mm dia with wall flange.", unit: "no", rate: 1000 },
        { sNo: "27.0", description: "Fittings/valves: Looking mirror 800x600mm complete set.", unit: "no", rate: 1200 },
        { sNo: "28.0", description: "Fittings/valves: Chrome plated toilet paper holder, flap type.", unit: "no", rate: 800 },
        { sNo: "29.0", description: "Fittings/valves: Chrome plated soap tray.", unit: "no", rate: 700 },
        { sNo: "30.0", description: "Fittings/valves: CP 15mm dia x450mm long towel rod, heavy.", unit: "no", rate: 1200 },
        { sNo: "31.0", description: "Fittings/valves: European pattern stainless steel 300mm bend-type grab bar.", unit: "no", rate: 2000 },
        { sNo: "32.0", description: "Floor drain set: uPVC multi-port floor trap.", unit: "no", rate: 800 },
        { sNo: "33.0", description: "Floor drain set: C.P. grating 110mm.", unit: "no", rate: 300 },
        { sNo: "34.0", description: "Floor drain set: 110mm uPVC gully trap with CI grating complete.", unit: "no", rate: 300 },
        { sNo: "35.0", description: "Overhead storage: 1000 litre plastic water tank with inlet, outlet, overflow, cleanout hole etc. complete.", unit: "no", rate: 12000 },
        { sNo: "36.0", description: "Water pumping set: 2.0 HP electric motor pump, multistage, supply and fixing complete.", unit: "no", rate: 12500 },
        { sNo: "37.0", description: "Water pumping set: Pressure sensor switch for pump auto switch off.", unit: "no", rate: 4000 },
        { sNo: "38.0", description: "Supply and fixing CPVC pipe (hot/cold), 15mm dia SDR 11 CTS, with fittings, clamps and jointing complete.", unit: "rm", rate: 180 },
        { sNo: "39.0", description: "Supply and fixing CPVC pipe (hot/cold), 20mm dia SDR 11 CTS, with fittings, clamps and jointing complete.", unit: "rm", rate: 200 },
        { sNo: "40.0", description: "Valves: 20mm dia CPVC ball valve, CTS socket, complete.", unit: "no", rate: 200 },
        { sNo: "41.0", description: "Soil waste and rainwater drainage pipe line, OD 75mm (6.0 kgf/sq cm) uPVC/PVC, complete with bends, tees, testing.", unit: "rm", rate: 450 },
        { sNo: "42.0", description: "Soil waste and rainwater drainage pipe line, OD 110mm (6.0 kgf/sq cm) uPVC/PVC, complete with bends, tees, testing.", unit: "rm", rate: 650 },
        { sNo: "43.0", description: "Manhole cover: CI cover 55x55cm size (medium).", unit: "no", rate: 4500 },
        { sNo: "44.0", description: "Electrical: Distribution board, wall mounting concealed type, 16 SWG MS sheet, 6-way, complete.", unit: "sets", rate: 18000 },
        { sNo: "45.0", description: "Electrical: 16A DP MCB (10kA).", unit: "nos", rate: 2500 },
        { sNo: "46.0", description: "Electrical: GFDB distribution board, wall mounting, 16 SWG MS sheet, 6-way, complete.", unit: "sets", rate: 8500 },
        { sNo: "47.0", description: "Electrical: 6 Amp SP MCB (10kA).", unit: "nos", rate: 250 },
        { sNo: "48.0", description: "Electrical: 16 Amp SP MCB (10kA).", unit: "nos", rate: 250 },
        { sNo: "49.0", description: "Electrical: Mains cable, 4 core 6 sq mm copper armoured, NEA meter to MDB, complete with cable shoes.", unit: "rm", rate: 180 },
        { sNo: "50.0", description: "Electrical: 2 core 6 sq mm copper unarmoured conductor, MDB to floor DBs.", unit: "rm", rate: 120 },
        { sNo: "51.0", description: "Electrical: 6 sq mm copper flexible cable for earthing, MDB to individual DBs.", unit: "rm", rate: 100 },
        { sNo: "52.0", description: "Electrical: Light point wiring from DB/junction/switch box to points, concealed conduit, complete.", unit: "pts", rate: 1000 },
        { sNo: "53.0", description: "Electrical: 26W LED tube light, ceiling mounted, complete.", unit: "nos", rate: 800 },
        { sNo: "54.0", description: "Electrical: 6W LED panel light, circular, ceiling mounted, complete.", unit: "nos", rate: 450 },
        { sNo: "55.0", description: "Electrical: Mirror light with 6W LED bulb, complete.", unit: "nos", rate: 2000 },
        { sNo: "56.0", description: "Electrical: Fan point wiring from DB/SDB to points, concealed conduit, complete.", unit: "pts", rate: 900 },
        { sNo: "57.0", description: "Electrical: 48\" normal speed ceiling fan.", unit: "nos", rate: 2750 },
        { sNo: "58.0", description: "Electrical: Modular type switch sockets with metal box and accessories.", unit: "nos", rate: 200 },
        { sNo: "59.0", description: "Electrical: 5 gang one-way switch, flush type.", unit: "nos", rate: 600 },
        { sNo: "60.0", description: "Electrical: 8 gang one-way switch, flush type.", unit: "nos", rate: 900 },
        { sNo: "61.0", description: "Electrical: Fan regulator and accessories complete.", unit: "nos", rate: 250 },
        { sNo: "62.0", description: "Electrical: 6/13/15A single phase 3/5 pin socket point wiring, concealed HDPE conduit, complete.", unit: "pts", rate: 1600 },
        { sNo: "63.0", description: "Electrical: 15A power socket - universal with control switch, modular, complete.", unit: "nos", rate: 300 },
        { sNo: "64.0", description: "Electrical: Earth electrode, 60x60x3mm copper plate, deep excavation/chemical earthing, <5 ohm.", unit: "nos", rate: 15000 },
        { sNo: "65.0", description: "Electrical: Telephone socket RJ11, flush mounting GI box.", unit: "nos", rate: 300 },
        { sNo: "66.0", description: "Electrical: Wiring for telephone point, 2-pair wire in 20mm PVC pipe, concealed, complete.", unit: "pts", rate: 1800 },
        { sNo: "67.0", description: "Electrical: Telephone DP, 18 SWG MS sheet, 20-pair IDC connector, complete.", unit: "set", rate: 5000 },
        { sNo: "68.0", description: "Electrical: Main Distribution Frame (MDF) 100 pair, 18 SWG GI sheet box, 80-pair IDC connector each side.", unit: "set", rate: 18000 },
        { sNo: "69.0", description: "Electrical: 20-pair telephone cable.", unit: "rm", rate: 80 },
        { sNo: "70.0", description: "Electrical: 20 pair GBPS computer LAN switch with 6U rack.", unit: "set", rate: 9000 },
        { sNo: "71.0", description: "Electrical: CAT 6 UTP computer networking backbone cable, 20 pair, server hub to switch, in PVC pipe.", unit: "rm", rate: 80 },
        { sNo: "72.0", description: "Electrical: RJ45 computer outlet with facia plate.", unit: "set", rate: 300 },
        { sNo: "73.0", description: "Electrical: Point wiring for computer outlet, CAT 6 UTP cable in PVC conduit, concealed.", unit: "pts", rate: 2000 }
      ]
    }
  ],
  vatPercent: 13
};

// Expose globally (no bundler — plain script include)
if (typeof module !== "undefined" && module.exports) {
  module.exports = DEFAULT_BOQ_TEMPLATE;
}
